g++ -o main main.cpp hcmcampaign.cpp -I . -std=c++11
./main